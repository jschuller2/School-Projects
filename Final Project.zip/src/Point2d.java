/**
 * This class holds a point value (x,y).  It prints out vt x y.
 * @author Jared
 * @email Jared@email.sc.edu
 * @date May 1, 2014
 */
public class Point2d {
	private float x;
	private float y;
	
	/**
	 * Constructor takes in the point values to begin with.
	 * @param x1 float - value on x-axis
	 * @param y1 float - value on y-axis
	 */
	public Point2d(float x1, float y1){
		x = x1;
		y = y1;
	}
	
	/**
	 * General constructor sets x and y values to 0.
	 */
	public Point2d(){
		x = 0;
		y = 0;
	}
	
	/**
	 * Returns value of x
	 * @return float - value of x
	 */
	public float getX(){
		return x;
	}
	
	/**
	 * Returns value of y
	 * @return float - value of y
	 */
	public float getY(){
		return y;
	}
	
	/**
	 * Sets the value of x
	 * @param x1 float - new value of x
	 */
	public void setX(float x1){
		x = x1;
	}
	
	/**
	 * Sets the value of y
	 * @param y1 float - new value of y
	 */
	public void setY(float y1){
		y = y1;
	}
	
	/**
	 * Changes out put to be vt x y
	 */
	@Override
	public String toString(){
		String out = " ";
		out ="vt " + x + " " + y + "\r\n";
		return out;
	}
}

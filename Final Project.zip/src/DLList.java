/**
 * This program creates a doubly link list that holds any one object type.  The list can be accessed from either end of it.
 * It can output its entire contents by calling toString.
 * @author Jared
 * @email jared@email.sc.edu
 * @date 3/28/2014
 * @param <T> making it generic
 */
public class DLList<T> {
	private DLLNode head;
	private DLLNode tail;
	private int cap;
	
	/**
	 * General constructor creates the list but it is empty
	 */
	public DLList(){
		head = null;
		tail = null;
		cap = 0;
	}
	
	/**
	 * Creates a new list with the head of the list being the input.
	 * @param t
	 */
	public DLList(T t){
		DLLNode node = new DLLNode(t);
		head = node;
		tail = node;
		cap = 1;
	}
	
	/**
	 * Adds a node to the end of the list that contains the input
	 * @param t the desired input to be added to the list
	 */
	public void add(T t){
		DLLNode node = new DLLNode(t);
		if(this.isEmpty()){
			head = node;
			tail = node;
		}
		else{
			tail.next = node;
			node.previous = tail;
		}
		cap ++;
		tail = node;
	}
	
	/**
	 * Adds a node to the list at the desired inputted index.
	 * @param index the desired place for the data
	 * @param t the data to be added
	 */
	public void add(int index, T t){
		DLLNode temp;
		DLLNode node = new DLLNode(t);
		
		if(cap/2 > index){
			//start from head
			temp = head;
			for(int i = 1; i<index; i++){
				temp = temp.next;
			}
		}
		else{
			temp = tail;
			for(int i = cap; i>index;i--){
				temp = temp.previous;
			}
		}
			node.next = temp.next;
			node.previous = temp;
			temp.next = node;
			node.next.previous = node;
	}
	
	/**
	 * Takes out the desired node at a place and returns what was taken out.
	 * @param index the desired node home for removal
	 * @return the data in the node removed
	 */
	public T remove(int index){
		DLLNode temp;
		if(cap/2 > index){
			temp = head; 
			for(int i = 1; i<index; i++) temp = temp.next;
		}
		else{
			temp = tail;
			for(int i = cap;i>index;i--)temp = temp.next;
		}
		temp.previous.next = temp.next;
		temp.next.previous = temp.previous;
		cap --;
		return temp.data;
	}
	
	/**
	 * checks to see if the desired data is in the list and if so returns true, otherwise it returns false
	 * @param t the desired data to be looked for
	 * @return true if there false otherwise
	 */
	public boolean contains(T t){
		DLLNode temp = head;
		for(int i = 1; i<cap; i++){
			if(t==temp.data) return true;
			temp = temp.next;
		}
		return false;
	}
	
	/**
	 * Returns the data at the specified index
	 * @param index the place of the desired data
	 * @return the data
	 */
	public T get(int index){
		DLLNode temp;
		if(cap/2 > index){
			temp = head; 
			for(int i = 1; i<index; i++) temp = temp.next;
		}
		else{
			temp = tail;
			for(int i = cap;i>index;i--)temp = temp.next;
		}
		
		return temp.data;
	}
	
	/**
	 * Returns the first index of the data otherwise returns -1 of not there.
	 * @param t desired data searched for
	 * @return the index of it or -1
	 */
	public int indexOf(T t){
		DLLNode temp = head;
		for(int i=1; i<cap;i++){
			if(temp.data == t) return i;
		}
		return -1;
	}
	
	/**
	 * Checks to see if the list is empty
	 * @return true if empty otherwise false
	 */
	public boolean isEmpty(){
		if(cap == 0) return true;
		else return false;
	}
	
	/**
	 * Returns the number of nodes in the list.
	 * @return
	 */
	public int size(){
		return cap;
	}
	
	/**
	 * Compares two objects and sees if they are equal.
	 */
	public boolean equals(Object o) {
		boolean isEqual = true;
		if(o != null){
			if(getClass() != o.getClass()) isEqual = false;
			else{
				DLList other = (DLList) o;
				if(head == null){
					if(other.head != null) isEqual = false; 
				}
				else if(!head.data.equals(other.head.data)) isEqual = false;
				
				if(cap != other.cap) isEqual = false;
				else {
					for(int i = 0; i < cap && isEqual; i++){
						if(!get(i).equals(other.get(i))) isEqual = false;
					}
				}
			}
		}
		return isEqual;
	}
	
	/**
	 * Takes all the data and puts into a string. Each data is seperated by a comma and a space
	 * @return the String of the list
	 */
	@Override
	public String toString(){
		String output = "";
		DLLNode temp = head;
		while(temp != null){
			output += temp.data;
			temp = temp.next;
		}
		return output;
	}
	
	/**
	 * This class holds the data that is in a list.
	 * @author Jared
	 *	@version 1.0
	 * @email jared@email.sc.edu
	 */
	private class DLLNode{
		private DLLNode next;
		private DLLNode previous;
		private T data;
		
		/**
		 * Creates a node and sets the next and previous to null
		 * @param data the data to be held
		 */
		public DLLNode(T data){
			this.data = data;
			previous = null;
			next = null;
		}
		
	}
}

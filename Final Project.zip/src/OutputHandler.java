import java.io.*;
/**
 * Creates both a .obj and a .mtl file for a model object.
 * @author Jared
 * @email jared@email.sc.edu
 * @date May 1, 2014
 */
public class OutputHandler {
	private Model m;
	private String fileName;
	
	/**
	 * Takes in the model and the DbgName of the object.
	 * @param mod Model - the information of the object to be created
	 * @param file String - the name of the new files.
	 */
	public OutputHandler(Model mod, String file){
		m = mod;
		fileName = file.substring(0,file.length()-3);
	}
	/**
	 * Creates a .mtl file using the materials object from the first mesh object in the model's 
	 * doubly link list
	 */
	public void printMtl(){
		try{
			PrintWriter pw = new PrintWriter(new File(fileName + ".mtl"));
			pw.print(m.getMesh().get(1).getMaterial());
			pw.close();
		}
		catch(FileNotFoundException e){
			System.out.print("Failed to load and create file.");
		}
	}
	
	/**
	 * Creates a .obj file using the faces, uvs, and vertices from the first mesh object
	 * in the model's doubly link list.
	 */
	public void printObj(){
		try{
			PrintWriter pw = new PrintWriter(new File(fileName + ".obj"));
			pw.println("mtllib " + fileName + ".mtl");
			pw.println("o" + " p" + fileName.substring(0,1).toUpperCase() + fileName.substring(1) + "1");
			pw.print(m.getMesh().get(1).getVertices());
			pw.print(m.getMesh().get(1).getUvs());
			pw.println("usemtl " + fileName + "MTL");
			pw.println("s 1");
			pw.print(m.getMesh().get(1).getFaces());
			pw.close();
		}
		catch(FileNotFoundException e){
			System.out.println("Failed to load and creat file.");
		}
		
	}
}

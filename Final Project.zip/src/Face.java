/**
 * Holds all the information needed for a face including the vertex indicies and uvs indecies
 * @author Jared
 * @email jared@email.sc.edu
 * @date May 1, 2014
 */
public class Face {
	private int vertIndex1;
	private int vertIndex2;
	private int vertIndex3;
	private int vertIndex4;
	private int uvIndex1;
	private int uvIndex2;
	private int uvIndex3;
	private int uvIndex4;
	private int faceType;
	
	/**
	 * Creates a face with with either 3 or 4 points on the face
	 * @param i - int 10 or 11 to signify either 3 or 4 points on the face
	 */
	public Face(int i){
		this.faceType = i;
	}
	
	
	/**
	 * @return the vertIndex1
	 */
	public int getVertIndex1() {
		return vertIndex1;
	}

	/**
	 * @param vertIndex1 the vertIndex1 to set
	 */
	public void setVertIndex1(int vertIndex1) {
		this.vertIndex1 = vertIndex1;
	}

	/**
	 * @return the vertIndex2
	 */
	public int getVertIndex2() {
		return vertIndex2;
	}

	/**
	 * @param vertIndex2 the vertIndex2 to set
	 */
	public void setVertIndex2(int vertIndex2) {
		this.vertIndex2 = vertIndex2;
	}

	/**
	 * @return the vertIndex3
	 */
	public int getVertIndex3() {
		return vertIndex3;
	}

	/**
	 * @param vertIndex3 the vertIndex3 to set
	 */
	public void setVertIndex3(int vertIndex3) {
		this.vertIndex3 = vertIndex3;
	}

	/**
	 * @return the vertIndex4
	 */
	public int getVertIndex4() {
		return vertIndex4;
	}

	/**
	 * @param vertIndex4 the vertIndex4 to set
	 */
	public void setVertIndex4(int vertIndex4) {
		this.vertIndex4 = vertIndex4;
	}

	/**
	 * @return the uvIndex1
	 */
	public int getUvIndex1() {
		return uvIndex1;
	}

	/**
	 * @param uvIndex1 the uvIndex1 to set
	 */
	public void setUvIndex1(int uvIndex1) {
		this.uvIndex1 = uvIndex1;
	}

	/**
	 * @return the faceType
	 */
	public int getFaceType() {
		return faceType;
	}

	/**
	 * @param faceType the faceType to set
	 */
	public void setFaceType(int faceType) {
		this.faceType = faceType;
	}

	/**
	 * @return the uvIndex2
	 */
	public int getUvIndex2() {
		return uvIndex2;
	}

	/**
	 * @param uvIndex2 the uvIndex2 to set
	 */
	public void setUvIndex2(int uvIndex2) {
		this.uvIndex2 = uvIndex2;
	}

	/**
	 * @return the uvIndex3
	 */
	public int getUvIndex3() {
		return uvIndex3;
	}

	/**
	 * @param uvIndex3 the uvIndex3 to set
	 */
	public void setUvIndex3(int uvIndex3) {
		this.uvIndex3 = uvIndex3;
	}

	/**
	 * @return the uvIndex4
	 */
	public int getUvIndex4() {
		return uvIndex4;
	}

	/**
	 * @param uvIndex4 the uvIndex4 to set
	 */
	public void setUvIndex4(int uvIndex4) {
		this.uvIndex4 = uvIndex4;
	}
	
	/**
	 * Changes the output to fit the face format of the upload process to .mtl and .obj files
	 */
	@Override
	public String toString(){
		String out = "";
		if(this.faceType == 11){
			out = "f " + vertIndex1 + "/" + uvIndex1 + " " + vertIndex2 + "/" + uvIndex2 + " " + vertIndex3 + "/" + uvIndex3 + " " + vertIndex4 + "/" + uvIndex4 + "\r\n";
		}
		else{
			out ="f " + vertIndex1 + "/" + uvIndex1 + " " + vertIndex2 + "/" + uvIndex2 + " " + vertIndex3 + "/" + uvIndex3 + "\r\n";
		}
		return out;
	}
	
}

/**
 * Creates a MAterial object to be a helper class to help create output files of .mtl and .obj.  This holds
 * the specifications of online 3D object generators.
 * 
 * @author Jared
 * @email Jared.sc.edu
 * @date May 1, 2014
 */
public class Material {
	private String mtlName;
	private float specularity;
	private float[] ambient;
	private float[] diffuse;
	private float[] specularColor;
	private float opticalDensity;
	private float alpha;
	private byte illum;
	private String ambientTexture;
	private String diffuseTexture;
	private String alphaTexture;
	
	/**
	 * Constructor takes all the needed values in the color rendering of the 3D object
	 * @param name String - the MtlName
	 * @param Ns float - specularity value
	 * @param Ka float[] - the three ambient values
	 * @param Kd float[] - the three diffuse values
	 * @param Ks float[] - the three specular color values
	 * @param Ni float - the optical density value
	 * @param d float - the alpha value
	 * @param Illum byte - the illum value
	 * @param map_Ka String - the ambient texture
	 * @param map_Kd String - the diffuse texture
	 * @param map_d String - the alpha texture
	 */
	public Material(String name, float Ns, float[] Ka, float[] Kd, float[] Ks, float Ni, float d, byte Illum, String map_Ka, String map_Kd, String map_d){
		mtlName = name;
		specularity = Ns;
		ambient = Ka;
		diffuse = Kd;
		specularColor = Ks;
		opticalDensity = Ni;
		alpha = d;
		illum = Illum;
		ambientTexture = map_Ka;
		diffuseTexture = map_Kd;
		alphaTexture = map_d;
	}
	
	/**
	 * @return String - the mtlname
	 */
	public String MtlName(){
		return mtlName;
	}
	
	/**
	 * @return float - the specularity value
	 */
	public float Ns(){
		return specularity;
	}
	
	/**
	 * @return float[] - the three ambient values
	 */
	public float[] Ka(){
		return ambient;
	}
	
	/**
	 * 
	 * @return float[] - the three diffuse values
	 */
	public float[] Kd(){
		return diffuse;
	}
	
	/**
	 * 
	 * @return float[] - the three specular color values
	 */
	public float[] Ks(){
		return specularColor;
	}
	/**
	 * 
	 * @return float - the alpha value
	 */
	public float d(){
		return alpha;
	}
	/**
	 * 
	 * @return byte - the illum value
	 */
	public byte Illum(){
		return illum;
	}
	/**
	 * 
	 * @return String - The ambient texture
	 */
	public String map_Ka(){
		return ambientTexture;
	}
	/**
	 * 
	 * @return String - the diffuse texture
	 */
	public String map_Kd(){
		return diffuseTexture;
	}
	/**
	 * 
	 * @return String - the alpha texture
	 */
	public String map_d(){
		return alphaTexture;
	}
	/**
	 * 
	 * @return float - the value of the optical density
	 */
	public float Ni(){
		return opticalDensity;
	}
	
	/**
	 * Changes to fit the output to match the organization of the .mtl and .obj spefications
	 */
	@Override
	public String toString(){
		String out = "";
		out += "newmtl " + mtlName + "\r\n";
		out += "Ns " + specularity + "\r\n";
		out += "Ka ";
		for(int i = 0; i<3; i++){
			out += ambient[i] + " ";
		}
		out += "\r\n";
		out += "Kd ";
		for(int i = 0; i<3; i++){
			out += diffuse[i] + " ";
		}
		out += "\r\n";
		out += "Ks ";
		for(int i = 0; i<3; i++){
			out += specularColor[i] + " ";
		}
		out += "\r\n";
		out += "Ni " + opticalDensity +"\r\n";
		out += "d " + alpha + "\r\n";
		out += "illum " + this.illum + "\r\n";
		if(!ambientTexture.equals(""))	out += "map_Ka " + ambientTexture + "\r\n";
		out += "map_Kd " + diffuseTexture + "\r\n";
		out += "map_d " + alphaTexture + "\r\n";
		return out;
	}
	
}

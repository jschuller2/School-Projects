import java.io.File; 
import java.io.FileNotFoundException; 
import java.util.Scanner; 
 
/** 
 * InputHandler: A class responsible for opening and getting data out 
 * of a file. 
 * 
 * @author Jared Schuller 
 * @email jared@email.sc.edu
 * @date May 1, 2014 
 */ 
public class InputHandler { 
	private String input;
	private String fileName;
	private DLList<Point3D> verts = new DLList<Point3D>();
	private DLList<Point2d> uvs = new DLList<Point2d>();
	private DLList<Face> faces = new DLList<Face>();
	private Material m;
	private String DbgName;
	
	/**
	 * Gets the file then takes the input from it
	 * @param name String - file path of the file to get the input from
	 */
	public InputHandler(String name){
		fileName = name;
	}
	/**
	 * Tries to open the file.  If successful takes the first line of the file then closes it.
	 * After that it calls all the other methods to parse specific material from the input it got from the file.
	 * It then creates a mesh and model class before finally calling output handler class.  If it can't open
	 * the file, it has the system print out a error and redisplays the input path of the file.
	 */
	public void parseFile(){
		try{
			Scanner file = new Scanner(new File(fileName));
			input = file.nextLine();
			file.close();
			this.parseFaces();
			this.parseMaterials();
			this.parseVerts();
			this.parseUVS();
			Mesh mesh = new Mesh(m, faces, uvs, verts);
			DLList<Mesh> meshes = new DLList<Mesh>();
			meshes.add(mesh);
			Model mod = new Model(meshes);
			OutputHandler out = new OutputHandler(mod, DbgName);
			out.printMtl();
			out.printObj();
		}
		catch(FileNotFoundException e){
			System.out.println("No such file found by the name of " + fileName);
		}
		
	}
	/**
	 * Goes through the input taking out all the faces in the first mesh.  It loops continuing to read the different types of faces
	 * by looking for the first spot for either a 10 or 11.  After that it takes in either the next 7 or 9 terms and creates a face object.
	 * Then it adds the face object to the face DLList and repeats until done.
	 */
	private void parseFaces(){
		
		int readhead = input.indexOf("\"faces\":");
		int readstop = input.indexOf("materials");
		Scanner s = new Scanner(input.substring(readhead,readstop-4));
		s.useDelimiter(",");
		while(s.hasNext()){
			if(s.next().contains("11")){
				Face temp = new Face(11);
				temp.setVertIndex1(s.nextInt() +1);
				temp.setVertIndex2(s.nextInt() +1);
				temp.setVertIndex3(s.nextInt() +1);
				temp.setVertIndex4(s.nextInt() +1);
				s.next();
				temp.setUvIndex1(s.nextInt() +1);
				temp.setUvIndex2(s.nextInt() +1);
				temp.setUvIndex3(s.nextInt() +1);
				temp.setUvIndex4(s.nextInt() +1);
				faces.add(temp);
			}
			else{
				Face temp = new Face(10);
				temp.setVertIndex1(s.nextInt() +1);
				temp.setVertIndex2(s.nextInt() +1);
				temp.setVertIndex3(s.nextInt() +1);
				s.next();
				temp.setUvIndex1(s.nextInt() +1);
				temp.setUvIndex2(s.nextInt() +1);
				temp.setUvIndex3(s.nextInt() +1);
				faces.add(temp);
			}
		}
		s.close();
	}
	/**
	 * Goes through the input taking out all the values of each of the parts of the material class object.  
	 * It gets the information by doing searches for key terms and then takes the next values it finds.
	 */
	private void parseMaterials(){
		int readhead = input.indexOf("specularCoef");
		String temp = input.substring(readhead);
		int commaIndex = temp.indexOf(",");
		String s1 = temp.substring(14,commaIndex);
		float Ns = Float.parseFloat(s1);

		readhead = input.indexOf("colorAmbient");
		temp = input.substring(readhead);
		int bracIndex = temp.indexOf("]");
		String s2 = temp.substring(14,bracIndex);
		commaIndex = s2.indexOf(",");
		float[] Ka = new float[3];
		String Ka0 = s2.substring(1,commaIndex);
		Ka[0] = Float.parseFloat(Ka0);
		String Ka1 = s2.substring(commaIndex+1,commaIndex+3);
		Ka[1] = Float.parseFloat(Ka1);
		String Ka2 = s2.substring(commaIndex+5,commaIndex+8);
		Ka[2] = Float.parseFloat(Ka2);
		
		readhead = input.indexOf("colorDiffuse");
		temp = input.substring(readhead);
		bracIndex = temp.indexOf("]");
		String s3 = temp.substring(14,bracIndex);
		commaIndex = s3.indexOf(",");
		float[] Kd = new float[3];
		String Kd0 = s3.substring(1,commaIndex);
		Kd[0] = Float.parseFloat(Kd0);
		String Kd1 = s3.substring(commaIndex+1,commaIndex+4);
		Kd[1] = Float.parseFloat(Kd1);
		String Kd2 = s3.substring(commaIndex+5,commaIndex+8);
		Kd[2] = Float.parseFloat(Kd2);
				
		readhead = input.indexOf("colorSpecular");
		temp = input.substring(readhead);
		bracIndex = temp.indexOf("]");
		String s4 = temp.substring(14,bracIndex);
		commaIndex = s4.indexOf(",");
		float [] Ks = new float[3];
		String Ks0 = s4.substring(2,commaIndex);
		Ks[0] = Float.parseFloat(Ks0);
		String Ks1 = s4.substring(commaIndex+1,commaIndex+4);
		Ks[1] = Float.parseFloat(Ks1);
		String Ks2 = s4.substring(commaIndex+6,commaIndex+8);
		Ks[2] = Float.parseFloat(Ks2);		
		
		readhead = input.indexOf("opticalDensity");
		temp = input.substring(readhead);
		commaIndex = temp.indexOf(",");
		String s5 = temp.substring(16,commaIndex);
		float Ni = Float.parseFloat(s5);
		
		readhead = input.indexOf("transparency");
		temp = input.substring(readhead);
		bracIndex = temp.indexOf("}");
		String s6 = temp.substring(14,bracIndex);
		float d = Float.parseFloat(s6);
		
		readhead = input.indexOf("illumination");
		temp = input.substring(readhead);
		commaIndex = temp.indexOf(",");
		String s7 = temp.substring(14,commaIndex);
		byte illum = Byte.parseByte(s7);
		
		String map_Ka = "";
		readhead = input.indexOf("ambientTexture");
		if(readhead != -1){
			temp = input.substring(readhead);
			commaIndex = temp.indexOf(",");
			map_Ka = temp.substring(11,commaIndex-1);
		}
		
		readhead = input.indexOf("mapDiffuse");
		temp = input.substring(readhead);
		commaIndex = temp.indexOf(",");
		String map_Kd = temp.substring(13,commaIndex-5);
		
		readhead = input.indexOf("mapAlpha");
		temp = input.substring(readhead);
		commaIndex = temp.indexOf(",");
		String map_d = temp.substring(11,commaIndex-1);
		
		readhead = input.indexOf("DbgName");
		DbgName = input.substring(readhead +10, input.indexOf("colorAmbient")-3);
		m = new Material(DbgName, Ns, Ka, Kd, Ks, Ni, d, illum, map_Ka, map_Kd, map_d);
	}
	/**
	 * Goes through the input looking for the chain of verticies and then creates 3D points from it by reading three values
	 * at a time until there are no more values.
	 */
	private void parseVerts(){
		int readhead = input.indexOf("\"vertices\":");
		int readstop = input.indexOf("for");
		Scanner s = new Scanner(input.substring(readhead + 13, readstop -6));
		s.useDelimiter(",");
		while(s.hasNext()){
			Point3D temp = new Point3D(s.nextFloat(), s.nextFloat(), s.nextFloat());
			verts.add(temp);
		}
		s.close();
		
	}
	
	/**
	 * Goes through the input looking for the listing of uv points and then takes two values at a time
	 * creating 2D points objects before adding them to the DLList of uvs.
	 */
	private void parseUVS(){
		int readhead = input.indexOf("\"uvs\":");
		int readstop = input.indexOf("version");
		Scanner s = new Scanner(input.substring(readhead +9, readstop -5));
		s.useDelimiter(",");
		while(s.hasNextFloat()){
			Point2d temp = new Point2d(s.nextFloat(),1 - s.nextFloat());
			uvs.add(temp);
		}
		s.close();
	}
		
}	

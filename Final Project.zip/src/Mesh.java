/**
 * A mesh class that holds a DLList of faces, a DLList of uvs, a DLList of vertices, and a Material object.
 * @author Jared
 * @email jared@email.sc.edu
 * @date MAy 1, 2014
 */
public class Mesh {
	private Material m;
	private DLList<Face> faces;
	private DLList<Point2d> Uvs;
	private DLList<Point3D> Verts;
	
	/**
	 * Creates a mesh object taking in the faces doubly link list, the uvs doubly link list, the vertices link list,and the material object
	 * @param m1 Materal - the filled material class for this mesh
	 * @param f DLList<Face> - all the faces of the object
	 * @param u DLList<Point2d> - all the uvs of the object
	 * @param v DLList<Point3D> - all the vertices of the object
	 */
	public Mesh(Material m1, DLList<Face> f, DLList<Point2d> u, DLList<Point3D> v){
		m = m1;
		faces = f;
		Uvs = u;
		Verts = v;
	}
	
	/**
	 * Generates the output for the .mtl and .obj files in the correct format.
	 */
	@Override
	public String toString(){
		String out = "";
		out += m + "\r\n";
		out += faces + "\r\n";
		out += Uvs + "\r\n";
		out += Verts + "\r\n";
		return out;
	}
	/**
	 * 
	 * @return Material - the material object for this mesh
	 */
	public Material getMaterial(){
		return m;
	}
	
	/**
	 * 
	 * @return DLList<Face> - all of the faces for the mesh object
	 */
	public DLList<Face> getFaces(){
		return faces;
	}
	/**
	 * 
	 * @return DLList<Point2d> - all of the uvs for the mesh object
	 */
	public DLList<Point2d> getUvs(){
		return Uvs;
	}
	/**
	 * 
	 * @return DLList<Point3D> - all of the vertices for the mesh object
	 */
	public DLList<Point3D> getVertices(){
		return Verts;
	}
}

/**
 * Creates and holds a 3-D point.
 * @author Jared
 * @email Jared@email.sc.edu
 * @date May 1, 2013
 */
public class Point3D {
	private float x;
	private float y;
	private float z;
	
	/**
	 * Creates a 3D point at the input values
	 * @param x1 float - value of x
	 * @param y1 float - value of y
	 * @param z1 float - value of z
	 */
	public Point3D(float x1, float y1, float z1){
		x = x1;
		y = y1;
		z = z1;
	}
	
	/**
	 * Returns value of x
	 * @return float - value of x
	 */
	public float getX(){
		return x;
	}
	
	/**
	 * Returns value of y
	 * @return float - value of y
	 */
	public float getY(){
		return y;
	}
	
	/**
	 * Returns value of x
	 * @return float - value of z
	 */
	public float getZ(){
		return z;
	}
	
	/**
	 * Sets the value of X
	 * @param x1 - float value of x
	 */
	public void setX(float x1){
		x = x1;
	}
	
	/**
	 * Sets the value of y
	 * @param y1 - float value of y
	 */
	public void setY(float y1){
		y = y1;
	}
	
	/**
	 * Sets the value of z
	 * @param z1 - float value of z
	 */
	public void setZ(float z1){
		z = z1;
	}
	
	/**
	 * Changes the output of it to v x y z
	 */
	@Override
	public String toString(){
		String out = ""; 
		out ="v " + x + " " + y + " " + z + "\r\n";
		return out;
	}
}

/**
 * Runs the the inputhandler class and passes in what file is to be parsed
 * @author Jared
 * @email jared@email.sc.edu
 * @date MAy 1, 2014
 */
public class Program {
	
	public static void main(String[] args){
		InputHandler x = new InputHandler("C:\\Users\\Jared\\Documents\\College\\Freshman\\CSCE 146\\Final Project\\src\\stream.txt");
		
		x.parseFile();
	}

}

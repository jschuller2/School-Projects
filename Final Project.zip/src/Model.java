/**
 * This holds all the formatted parsed information for one object.  It holds a doubly link list of meshes.
 * @author Jared
 * @email jared@email.sc.edu
 * @date May 1, 2014
 */
public class Model {
	private DLList<Mesh> mesh = new DLList<Mesh>();
	
	/**
	 * Creates a model by taking in a doubly link list of filled mesh objects
	 * @param m DLList<Mesh> - the completed mesh classes
	 */
	public Model(DLList<Mesh> m){
		mesh = m;
	}
	
	/**
	 * Prints out all the meshes
	 */
	@Override
	public String toString(){
		String out = mesh.toString();
		return out;
	}

	/**
	 * 
	 * @return DLList<Mesh> all of the mesh objects for this object
	 */
	public DLList<Mesh> getMesh() {
		// TODO Auto-generated method stub
		return mesh;
	}
}
